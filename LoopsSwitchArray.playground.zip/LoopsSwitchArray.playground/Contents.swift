import UIKit


//Array Task
var books = ["What I Know For Sure", "The Four greement", "Automic Habits "]

books.count

books.append("The Five People You Met in Heaven")

books.insert("Finding Chika", at: 2)

books.remove(at: 2)

//Switch Task

let grade = "B"
switch grade {
case "A":
    print("Excellent")
case "B":
    print("Good")
case "C":
    print("Average")
case "D":
    print("Below Average")
case "F":
    print("Poor")
default:
    print("Error!")
}

let trafficLight = "red"
switch trafficLight{
case "red":
    print("Stop")
case "yellow":
    print("Get Ready")
case "green":
    print("Go")
default:
    print("Wait!")
}

//Loops Task
var favoriteFruit = ["Apple", "Banana", "Cherry"]

for fav in favoriteFruit{
    print(fav)
}

for i in 1...5{
    
    for j in 1...5{
        let result = i*j
        print("\(i)*\(j)= \(result)")
    }
}









